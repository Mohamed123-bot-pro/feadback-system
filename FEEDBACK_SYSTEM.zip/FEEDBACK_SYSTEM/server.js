const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
require('dotenv').config();
const config = require('./config');
const Feedback = require('./Feedback');

mongoose.connect(config.mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(__dirname));

app.post('/submit-feedback', (req, res) => {
  const { name, faculty, message } = req.body;
  const newFeedback = new Feedback({ name, faculty, message });

  newFeedback.save()
    .then(() => res.redirect('/thankyou.html'))
    .catch(err => {
      console.error('❌ Error saving feedback:', err);
      res.status(500).send('Database error');
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
